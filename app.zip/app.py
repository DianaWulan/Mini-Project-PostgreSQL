from flask import Flask, render_template, request, redirect
import psycopg2

app = Flask(__name__)

# Fungsi koneksi ke PostgreSQL
def get_db_connection():
    conn = psycopg2.connect("dbname=employee_management user=postgres password=postgres")
    return conn

# Menampilkan semua data karyawan
@app.route('/')
def index():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM employees;')
    employees = cur.fetchall()
    cur.close()
    conn.close()
    return render_template('index.html', employees=employees)

# Menampilkan form untuk menambah karyawan baru
@app.route('/add')
def add_employee():
    return render_template('add.html')

# Menambah karyawan baru ke database
@app.route('/add-employee', methods=['POST'])
def add_employee_post():
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    department_id = request.form['department_id']

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('''
        INSERT INTO employees (first_name, last_name, email, department_id)
        VALUES (%s, %s, %s, %s);
    ''', (first_name, last_name, email, department_id))
    conn.commit()
    cur.close()
    conn.close()
    return redirect('/')

# Menampilkan form untuk mengedit karyawan
@app.route('/edit/<int:id>')
def edit_employee(id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM employees WHERE employee_id = %s', (id,))
    employee = cur.fetchone()
    cur.close()
    conn.close()
    return render_template('edit.html', employee=employee)

# Mengedit data karyawan
@app.route('/update-employee/<int:id>', methods=['POST'])
def update_employee(id):
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    email = request.form['email']
    department_id = request.form['department_id']

    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('''
        UPDATE employees
        SET first_name = %s, last_name = %s, email = %s, department_id = %s
        WHERE employee_id = %s;
    ''', (first_name, last_name, email, department_id, id))
    conn.commit()
    cur.close()
    conn.close()
    return redirect('/')

# Menghapus karyawan
@app.route('/delete/<int:id>')
def delete_employee(id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM employees WHERE employee_id = %s', (id,))
    conn.commit()
    cur.close()
    conn.close()
    return redirect('/')

if __name__ == "__main__":
    app.run(debug=True)
